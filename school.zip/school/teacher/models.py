from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

# Create your models here.

g= (("Male","Male"),("Female","Female"))
s= (("English","English"),("Computer Science","Computer Science"))

class Teachers(models.Model):
 user = models.ForeignKey(User,on_delete = models.CASCADE)
 serno = models.AutoField(primary_key=True)
 name = models.CharField(max_length = 30)
 email = models.EmailField()
 subject = models.CharField(max_length = 50,choices = s)
 gender = models.CharField(max_length = 7, choices = g)
 date = models.DateTimeField()

def __str__(self):
    return self.name
