from django.urls import path
from teacher import views

urlpatterns = [
    path('',views.index,name="teachers"),
    path('registration',views.registrations,name="registration"),
    path('login',views.loginpage,name="login"),
    
   
]
