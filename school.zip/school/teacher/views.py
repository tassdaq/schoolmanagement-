from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout

# Create your views here.
def index(request):
    return render(request,("teacher/teachers.html"))

def registrations(request):
    if request.method =="POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password1 = request.POST.get('password1')

        if password!=password1:
         messages.error(request,"Your Password is not same")

        else:    

         my_user = User.objects.create_user(username,email,password)
         my_user.save()
         return redirect('/teacher/login')
    return render(request,("teacher/registration.html"))

def loginpage(request):
    if request.method =="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request,username= username, password= password)
        
        if user is not None:
    # A backend authenticated the credentials
            login(request,user)
            
            return redirect ("/teacher")
        else:

           
            return redirect("/teacher/login") 
    return render(request,("teacher/login.html"))
