from django.contrib import admin
from teacher.models import Teachers
# Register your models here.
admin.site.register(Teachers)