from django.contrib import admin
from .models import Admissionforms,Contact,Recordfee,Teachers
# Register your models here.
admin.site.register(Admissionforms)
admin.site.register(Contact)
admin.site.register(Recordfee)
admin.site.register(Teachers)